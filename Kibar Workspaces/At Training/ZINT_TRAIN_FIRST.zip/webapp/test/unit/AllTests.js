sap.ui.define([
	"int/train/first/ZINT_TRAIN_FIRST/test/unit/controller/App.controller"
], function () {
	"use strict";
});