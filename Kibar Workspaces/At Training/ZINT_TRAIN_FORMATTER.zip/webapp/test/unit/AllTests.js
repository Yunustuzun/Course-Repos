sap.ui.define([
	"int/train/formatter/ZINT_TRAIN_FORMATTER/test/unit/controller/App.controller"
], function () {
	"use strict";
});