sap.ui.define([
	"int/train/binding1/ZINT_TRAIN_BINDING1/test/unit/controller/Home.controller"
], function () {
	"use strict";
});