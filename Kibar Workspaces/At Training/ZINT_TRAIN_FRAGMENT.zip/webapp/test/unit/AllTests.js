sap.ui.define([
	"int/train/fragment/ZINT_TRAIN_FRAGMENT/test/unit/controller/App.controller"
], function () {
	"use strict";
});