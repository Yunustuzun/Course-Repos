sap.ui.define([
	"int/train/field_group/ZINT_TRAIN_FIELD_GROUP/test/unit/controller/App.controller"
], function () {
	"use strict";
});