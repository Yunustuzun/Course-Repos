sap.ui.define([
	"int/train/odata/ZINT_TRAIN_ODATA/test/unit/controller/App.controller"
], function () {
	"use strict";
});