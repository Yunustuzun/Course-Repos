sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("int.train.router.ZINT_TRAIN_ROUTER.controller.App", {
		onInit: function () {

		}
	});
});