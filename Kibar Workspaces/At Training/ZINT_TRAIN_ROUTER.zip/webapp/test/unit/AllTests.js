sap.ui.define([
	"int/train/router/ZINT_TRAIN_ROUTER/test/unit/controller/App.controller"
], function () {
	"use strict";
});