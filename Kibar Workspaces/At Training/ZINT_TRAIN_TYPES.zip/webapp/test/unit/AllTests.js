sap.ui.define([
	"int/train/types/ZINT_TRAIN_TYPES/test/unit/controller/App.controller"
], function () {
	"use strict";
});