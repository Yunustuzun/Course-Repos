sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("int.train.rezervation.ZINT_TRAIN_REZERVATION.controller.DetailObjectNotFound", {});
});
