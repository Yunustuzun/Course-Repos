sap.ui.define([
	"int/train/mvc1/ZINT_TRAIN_MVC1/test/unit/controller/App.controller"
], function () {
	"use strict";
});